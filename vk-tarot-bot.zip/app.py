import os
import json
import random
import requests
from flask import Flask, request

app = Flask(__name__)

VK_TOKEN = os.getenv("VK_TOKEN")
CONFIRMATION_CODE = os.getenv("CONFIRMATION_CODE")
SECRET_KEY = os.getenv("SECRET_KEY", "")
VK_API_VERSION = "5.199"

KEYWORDS = {
    "сердце": "love",
    "любовь": "love",
    "чувствую": "love",
    "правда": "love",

    "деньги": "money",
    "финансы": "money",

    "будущее": "future",
    "судьба": "future",

    "нет": "energy",
    "отдых": "energy",
}


def load_messages(category):
    with open(f"messages/{category}.json", "r", encoding="utf-8") as file:
        return json.load(file)


def vk_api(method, params):
    params["access_token"] = VK_TOKEN
    params["v"] = VK_API_VERSION
    response = requests.post(
        f"https://api.vk.com/method/{method}",
        data=params,
        timeout=10
    )
    return response.json()


def choose_message(text):
    text = (text or "").lower()

    for keyword, category in KEYWORDS.items():
        if keyword in text:
            messages = load_messages(category)
            return random.choice(messages)

    return None


def reply_to_comment(owner_id, post_id, comment_id, message):
    return vk_api("wall.createComment", {
        "owner_id": owner_id,
        "post_id": post_id,
        "reply_to_comment": comment_id,
        "message": f"✨ Послание для вас:\n\n{message}"
    })


def send_private_message(user_id, message):
    return vk_api("messages.send", {
        "user_id": user_id,
        "random_id": random.randint(1, 2_000_000_000),
        "message": f"✨ Послание для вас:\n\n{message}"
    })


@app.route("/", methods=["GET"])
def index():
    return "VK Tarot Bot is working"


@app.route("/callback", methods=["POST"])
def callback():
    data = request.json or {}

    if SECRET_KEY and data.get("secret") != SECRET_KEY:
        return "forbidden", 403

    if data.get("type") == "confirmation":
        return CONFIRMATION_CODE or ""

    if data.get("type") == "wall_reply_new":
        obj = data.get("object", {})

        comment_text = obj.get("text", "")
        user_id = obj.get("from_id")
        post_id = obj.get("post_id")
        comment_id = obj.get("id")
        owner_id = obj.get("owner_id")

        message = choose_message(comment_text)

        if message:
            reply_to_comment(owner_id, post_id, comment_id, message)

            # VK может не дать отправить ЛС, если человек не писал сообществу.
            try:
                send_private_message(user_id, message)
            except Exception as error:
                print("Cannot send private message:", error)

    return "ok"


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
