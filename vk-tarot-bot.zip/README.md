# VK Tarot Bot

Бот для VK Callback API.

Что делает:
- ловит комментарии под постами;
- ищет ключевые слова;
- выбирает случайное послание;
- отвечает под комментарием;
- отправляет тот же текст в личные сообщения, если VK разрешает.

## Переменные окружения Render

Добавить в Render → Environment:

- `VK_TOKEN`
- `CONFIRMATION_CODE`
- `SECRET_KEY`

## URL для Callback API

После деплоя в Render используй:

`https://ТВОЙ-АДРЕС.onrender.com/callback`
